package com.pluto.assistant

import android.content.Context
import android.provider.ContactsContract

data class Contact(val name: String, val phoneNumber: String)

object ContactHelper {

    /**
     * Fuzzy-finds a contact by spoken name. Speech recognition rarely gets
     * names exactly right, so this does a simple "contains" / normalized
     * match rather than requiring an exact string.
     */
    fun findContact(context: Context, spokenName: String): Contact? {
        val target = normalize(spokenName)
        if (target.isBlank()) return null

        val resolver = context.contentResolver
        val cursor = resolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        ) ?: return null

        var best: Contact? = null
        cursor.use {
            val nameIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numberIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (it.moveToNext()) {
                val name = it.getString(nameIdx) ?: continue
                val number = it.getString(numberIdx) ?: continue
                val normalizedContactName = normalize(name)
                if (normalizedContactName == target) {
                    // exact match wins immediately
                    return Contact(name, number)
                }
                if (best == null && (normalizedContactName.contains(target) || target.contains(normalizedContactName))) {
                    best = Contact(name, number)
                }
            }
        }
        return best
    }

    private fun normalize(s: String) = s.lowercase().replace(Regex("[^a-z0-9ஂ-௿]"), "").trim()
}
