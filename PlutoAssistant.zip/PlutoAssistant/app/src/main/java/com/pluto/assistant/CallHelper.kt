package com.pluto.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.ContextCompat

object CallHelper {

    /** Places a call directly — no dialer tap needed — given CALL_PHONE permission is granted. */
    fun callNumber(context: Context, phoneNumber: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_CALL).apply {
                data = Uri.parse("tel:$phoneNumber")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            true
        } catch (e: SecurityException) {
            false
        }
    }
}
