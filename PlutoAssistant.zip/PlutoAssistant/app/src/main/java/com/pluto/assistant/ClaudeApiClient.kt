package com.pluto.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Sends the user's spoken question to Claude and returns a spoken-friendly
 * answer. Enables Claude's web_search tool so Pluto can answer questions
 * about current events, not just its training knowledge — this is what
 * gives it the "ask JARVIS anything" feel.
 *
 * SECURITY NOTE: never ship your real API key inside the app. Route this
 * call through your own backend (even a tiny serverless function) that
 * holds the key server-side, and have the app call your backend instead.
 * The placeholder below assumes such a backend at BACKEND_URL.
 */
object ClaudeApiClient {

    // Replace with your own backend endpoint that forwards to
    // https://api.anthropic.com/v1/messages using your server-held API key.
    private const val BACKEND_URL = "https://your-backend.example.com/ask"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun ask(question: String, replyInTamil: Boolean): String = withContext(Dispatchers.IO) {
        try {
            val systemPrompt = if (replyInTamil) {
                "You are Pluto, a witty and helpful voice assistant in the style of JARVIS. " +
                    "Reply concisely in Tamil (2-3 sentences), suitable for being spoken aloud."
            } else {
                "You are Pluto, a witty and helpful voice assistant in the style of JARVIS. " +
                    "Reply concisely (2-3 sentences), suitable for being spoken aloud."
            }

            val body = JSONObject().apply {
                put("system", systemPrompt)
                put("question", question)
            }

            val request = Request.Builder()
                .url(BACKEND_URL)
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext "Sorry, I couldn't reach the server."
                val json = JSONObject(response.body?.string() ?: "{}")
                json.optString("answer", "Sorry, I didn't get a clear answer.")
            }
        } catch (e: Exception) {
            "Sorry, something went wrong reaching the internet."
        }
    }
}

/*
 * Example minimal backend (Node.js / any serverless function) this app expects:
 *
 * POST /ask   body: { "system": "...", "question": "..." }
 *
 * const resp = await fetch("https://api.anthropic.com/v1/messages", {
 *   method: "POST",
 *   headers: {
 *     "x-api-key": process.env.ANTHROPIC_API_KEY,
 *     "anthropic-version": "2023-06-01",
 *     "content-type": "application/json",
 *   },
 *   body: JSON.stringify({
 *     model: "claude-sonnet-4-6",
 *     max_tokens: 300,
 *     system: req.body.system,
 *     messages: [{ role: "user", content: req.body.question }],
 *     tools: [{ type: "web_search_20250305", name: "web_search" }],
 *   }),
 * });
 * const data = await resp.json();
 * const answer = data.content.filter(b => b.type === "text").map(b => b.text).join(" ");
 * res.json({ answer });
 */
