package com.pluto.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

class VoiceOutput(context: Context) {

    private var tts: TextToSpeech? = null
    private var ready = false

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                // Falls back to English gracefully if the Tamil TTS voice
                // isn't installed on the device (Settings > Language > Text-to-speech).
                val result = tts?.setLanguage(Locale("ta", "IN"))
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.setLanguage(Locale.ENGLISH)
                }
                ready = true
            }
        }
    }

    fun speak(text: String) {
        if (!ready) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "pluto_utterance")
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
