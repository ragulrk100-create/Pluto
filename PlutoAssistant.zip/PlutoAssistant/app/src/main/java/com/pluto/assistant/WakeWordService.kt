package com.pluto.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Listens continuously for "Hey Pluto" and then captures the follow-up
 * command. Uses Android's built-in SpeechRecognizer in a restart loop.
 *
 * HONEST LIMITATION: Android's on-device continuous listening is not as
 * seamless as a dedicated wake-word engine (e.g. Picovoice Porcupine).
 * SpeechRecognizer needs network for best accuracy, times out after each
 * phrase, and restarting it in a tight loop drains battery. For a truly
 * robust always-on wake word with low power draw, swap this for Porcupine
 * or a similar on-device keyword spotter and only invoke SpeechRecognizer
 * once the wake word is detected.
 */
class WakeWordService : Service(), RecognitionListener {

    private var recognizer: SpeechRecognizer? = null
    private var listeningForCommand = false
    private lateinit var voiceOutput: VoiceOutput
    private val scope = CoroutineScope(Dispatchers.Main)

    override fun onCreate() {
        super.onCreate()
        voiceOutput = VoiceOutput(this)
        startForeground(NOTIFICATION_ID, buildNotification())
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(this@WakeWordService)
        }
        startListening()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    private fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            // ta-IN gives best results for Tamil commands; SpeechRecognizer
            // still generally understands mixed Tamil/English speech.
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ta-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        recognizer?.startListening(intent)
    }

    override fun onResults(results: Bundle?) {
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val text = matches?.firstOrNull().orEmpty()
        handleTranscript(text)
        // Restart listening loop
        startListening()
    }

    private fun handleTranscript(text: String) {
        val lower = text.lowercase()
        if (!listeningForCommand) {
            if (lower.contains("pluto") || lower.contains("ப்ளூட்டோ")) {
                listeningForCommand = true
                voiceOutput.speak("சொல்லுங்க") // "Tell me" / "Go ahead"
                // The wake word and the command often arrive in the same
                // utterance (e.g. "Hey Pluto call Kumar"), so also try
                // processing anything after "pluto" right away.
                val afterWake = lower.substringAfter("pluto", "").trim()
                if (afterWake.isNotBlank()) {
                    listeningForCommand = false
                    executeCommand(afterWake)
                }
            }
            return
        }

        listeningForCommand = false
        executeCommand(text)
    }

    private fun executeCommand(text: String) {
        when (val command = CommandProcessor.parse(text)) {
            is PlutoCommand.Call -> {
                val contact = ContactHelper.findContact(this, command.contactName)
                if (contact != null) {
                    voiceOutput.speak("${contact.name}-ku call pannuren")
                    CallHelper.callNumber(this, contact.phoneNumber)
                } else {
                    voiceOutput.speak("Contact-a kandupidikala")
                }
            }
            is PlutoCommand.WhatsAppMessage -> {
                val contact = ContactHelper.findContact(this, command.contactName)
                if (contact != null) {
                    voiceOutput.speak("${contact.name}-ku WhatsApp message anupuren")
                    WhatsAppAccessibilityService.PendingSend.armed = true
                    WhatsAppHelper.openChatWithMessage(this, contact.phoneNumber, command.message)
                } else {
                    voiceOutput.speak("Contact-a kandupidikala")
                }
            }
            is PlutoCommand.Question -> {
                scope.launch {
                    val answer = ClaudeApiClient.ask(command.text, replyInTamil = true)
                    voiceOutput.speak(answer)
                }
            }
            PlutoCommand.Unknown -> {
                voiceOutput.speak("Puriyala, innoru maari sollunga")
            }
        }
    }

    override fun onError(error: Int) {
        // Recognizer stops on silence/timeout/no-match — just restart the loop.
        startListening()
    }

    private fun buildNotification(): Notification {
        val channelId = "pluto_wake_word"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Pluto Assistant", NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Pluto is listening")
            .setContentText("Say \"Hey Pluto\" any time")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        voiceOutput.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // Unused RecognitionListener callbacks
    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}

    companion object {
        private const val NOTIFICATION_ID = 42
    }
}
