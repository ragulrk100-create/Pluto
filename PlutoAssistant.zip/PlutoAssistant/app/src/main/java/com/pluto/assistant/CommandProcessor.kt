package com.pluto.assistant

/**
 * Turns a transcribed voice command into a structured intent.
 * Supports mixed Tamil / English phrasing since most Tamil speakers
 * code-switch naturally ("Kumar-ku call pannu", "Kumar-ku whatsapp la
 * hi nu message anuppu").
 */
sealed class PlutoCommand {
    data class Call(val contactName: String) : PlutoCommand()
    data class WhatsAppMessage(val contactName: String, val message: String) : PlutoCommand()
    data class Question(val text: String) : PlutoCommand()
    object Unknown : PlutoCommand()
}

object CommandProcessor {

    // Tamil + English trigger words. Extend this list as you discover
    // real phrasing your users actually say.
    private val callWords = listOf("call pannu", "call panra", "call", "அழை", "போன் பண்ணு")
    private val whatsappWords = listOf("whatsapp", "வாட்ஸ்அப்", "message anuppu", "message send pannu")
    private val sayWords = listOf(" nu sona", " nu message", "solli", "என்று", " sollu")

    fun parse(rawText: String): PlutoCommand {
        val text = rawText.trim()
        val lower = text.lowercase()

        val isWhatsApp = whatsappWords.any { lower.contains(it) }
        val isCall = !isWhatsApp && callWords.any { lower.contains(it) }

        return when {
            isWhatsApp -> parseWhatsApp(text, lower)
            isCall -> parseCall(text, lower)
            else -> PlutoCommand.Question(text)
        }
    }

    private fun parseCall(text: String, lower: String): PlutoCommand {
        // e.g. "Kumar-ku call pannu" / "call Kumar" / "அம்மாவை அழை"
        var name = lower
        callWords.forEach { name = name.replace(it, "") }
        name = name.replace("-ku", "").replace("ஐ", "").replace("ஐ", "")
            .replace("ai", "").trim()
        return if (name.isNotBlank()) PlutoCommand.Call(name.trim()) else PlutoCommand.Unknown
    }

    private fun parseWhatsApp(text: String, lower: String): PlutoCommand {
        // e.g. "Kumar-ku whatsapp la hi nu message anuppu"
        // Strategy: find contact name before "whatsapp"/"-ku", and message
        // between the trigger word and the "nu message anuppu" tail.
        val whatsappIndex = whatsappWords.map { lower.indexOf(it) }.filter { it >= 0 }.minOrNull()
            ?: return PlutoCommand.Unknown

        val beforePart = text.substring(0, whatsappIndex).trim()
        val contactName = beforePart.replace("-ku", "", ignoreCase = true).trim()

        var afterPart = text.substring(whatsappIndex).trim()
        whatsappWords.forEach { afterPart = afterPart.replace(it, "", ignoreCase = true) }
        sayWords.forEach { afterPart = afterPart.replace(it, "", ignoreCase = true) }
        afterPart = afterPart.replace("la", "").replace("send pannu", "")
            .replace("anuppu", "").trim()

        return if (contactName.isNotBlank() && afterPart.isNotBlank()) {
            PlutoCommand.WhatsAppMessage(contactName, afterPart)
        } else {
            PlutoCommand.Unknown
        }
    }
}
