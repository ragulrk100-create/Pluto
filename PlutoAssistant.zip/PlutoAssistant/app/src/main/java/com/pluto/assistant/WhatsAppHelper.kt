package com.pluto.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri

object WhatsAppHelper {

    /**
     * Opens WhatsApp directly into a chat with the message pre-filled.
     * This part is fully supported by WhatsApp's own intent API.
     * The actual "tap send" step is done separately by
     * WhatsAppAccessibilityService once this chat screen is on top —
     * that part is unofficial automation, not something WhatsApp exposes.
     */
    fun openChatWithMessage(context: Context, phoneNumber: String, message: String): Boolean {
        return try {
            val cleanNumber = phoneNumber.filter { it.isDigit() || it == '+' }
            val uri = Uri.parse(
                "https://api.whatsapp.com/send?phone=$cleanNumber&text=${Uri.encode(message)}"
            )
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage("com.whatsapp")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }
}
