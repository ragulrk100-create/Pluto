package com.pluto.assistant

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * IMPORTANT: Auto-tapping WhatsApp's Send button is NOT an official WhatsApp
 * feature. It works by reading WhatsApp's on-screen UI via the Accessibility
 * API and simulating a click — this is against WhatsApp's Terms of Service
 * and could get an account flagged or banned if used heavily. Use sparingly
 * and at your own risk.
 *
 * Safety design: this service ONLY auto-sends when Pluto itself just opened
 * the chat (see PendingSend.armed). It never touches WhatsApp otherwise, so
 * it won't interfere with messages you're typing yourself.
 */
class WhatsAppAccessibilityService : AccessibilityService() {

    object PendingSend {
        // Set to true right before Pluto opens the WhatsApp chat intent,
        // and cleared immediately after one send attempt (success or not).
        @Volatile var armed: Boolean = false
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!PendingSend.armed) return
        val root = rootInActiveWindow ?: return

        val sendButton = findSendButton(root)
        if (sendButton != null) {
            sendButton.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            PendingSend.armed = false
            Log.i("Pluto", "Auto-sent WhatsApp message via accessibility tap")
        }
    }

    private fun findSendButton(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        // WhatsApp's send button typically exposes content-description "Send".
        val byDesc = node.findAccessibilityNodeInfosByText("Send")
        for (candidate in byDesc) {
            if (candidate.isClickable) return candidate
        }
        // Fallback: search by resource id used by WhatsApp's send FAB.
        val byId = node.findAccessibilityNodeInfosByViewId("com.whatsapp:id/send")
        return byId.firstOrNull { it.isClickable }
    }

    override fun onInterrupt() {}
}
