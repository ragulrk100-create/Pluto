# Pluto — Tamil Voice Assistant (JARVIS-style)

## Building the APK from your phone (no laptop needed)

This project includes `.github/workflows/build.yml`, which builds a debug APK
on GitHub's own servers whenever you push code. You only need a phone browser.

1. **Create a GitHub account** if you don't have one (github.com, works fine in mobile Safari/Chrome).
2. **Create a new repository**: tap the "+" icon → "New repository" → name it `PlutoAssistant` → Create.
3. **Upload the project files**: on the repo's main page, tap "Add file" → "Upload files". Unzip `PlutoAssistant.zip` first using any file-manager app with unzip support (most Android/iOS file apps have this built in), then upload the extracted files/folders through that same screen — GitHub's upload page accepts multiple files and preserves folder paths if your file manager lets you select whole folders at once. If your phone can only upload files one at a time, upload folder by folder (start with `.github/workflows/build.yml`, then everything under `app/`, then the top-level `build.gradle`, `settings.gradle`, `README.md`).
4. Once everything is uploaded and committed to the `main` branch, GitHub automatically starts the build — go to the **Actions** tab of your repo to watch it run (takes about 3–5 minutes).
5. When it finishes with a green checkmark, open that run and scroll to **Artifacts** at the bottom → tap **pluto-debug-apk** to download it as a zip.
6. Unzip it on your phone (file manager app) to get `app-debug.apk`, then tap it to install. You'll need to allow "Install unknown apps" for your browser/file manager in Android Settings the first time.

If step 3 is too fiddly on your phone's upload UI, an easier alternative is installing **Termux** (from F-Droid) and running a few `git` commands to push the unzipped folder — happy to write out that exact command sequence if you'd rather do it that way.


## What this does
- Listens for **"Hey Pluto"** and takes a follow-up voice command, in Tamil or mixed Tamil/English.
- **"Kumar-ku call pannu"** → looks up Kumar in your contacts and places the call directly, no dialer tap.
- **"Kumar-ku whatsapp la hi nu message anuppu"** → opens WhatsApp with the message pre-filled to Kumar, then auto-taps Send via an Accessibility Service.
- **Any general question** → sent to Claude (with web search enabled) and spoken back in Tamil.

## Setup
1. Open this folder in Android Studio (Hedgehog or newer).
2. Deploy your own tiny backend that forwards requests to the Anthropic API (see the comment block at the bottom of `ClaudeApiClient.kt` for a ready-to-paste example) and put its URL in `ClaudeApiClient.BACKEND_URL`. **Never embed your Anthropic API key directly in the app** — anyone could extract it from the APK.
3. Build and install on a physical Android device (minSdk 26). Emulators don't handle mic input or telephony well for this.
4. On first launch, grant microphone, call, and contacts permissions when prompted.
5. Go to **Settings → Accessibility → Pluto** and turn the service on — this is what lets Pluto auto-tap WhatsApp's send button.
6. If you want a Tamil TTS voice, make sure one is installed under **Settings → Language → Text-to-speech output**. Most Android phones support Tamil out of the box (Google TTS engine).

## Things to know before you rely on this daily

- **WhatsApp auto-send violates WhatsApp's Terms of Service.** It works by reading WhatsApp's screen through Android's Accessibility API and simulating a tap — WhatsApp doesn't officially support this, and heavy automated use is a bannable pattern on their end. Consider keeping it to occasional personal use rather than something that fires constantly, and know the risk is real, not theoretical.
- **The wake word engine here is a restart-loop built on Android's SpeechRecognizer**, not a dedicated low-power keyword spotter. It works, but it needs network for best accuracy, briefly pauses between listens, and uses more battery than a proper always-on solution. For something closer to real JARVIS-style always-listening, swap in an on-device wake-word engine like **Picovoice Porcupine** (has a free tier, works offline, sips battery) and only invoke SpeechRecognizer after it fires.
- **Contact name matching is fuzzy, not perfect.** Speech recognition often mishears Tamil names. `ContactHelper` does substring matching, but you should test with your actual contact list and tune it.
- **Command parsing (`CommandProcessor.kt`) is a starting point.** Tamil speakers phrase things in a lot of different ways — treat the trigger-word lists as something to expand based on what you and your family/friends actually say to it.
- On Android 12+, background microphone access and foreground services are increasingly restricted by the OS for battery reasons — test real-world reliability on your specific phone model.

## File map
- `WakeWordService.kt` — always-on listening loop + dispatches commands
- `CommandProcessor.kt` — turns transcribed text into Call / WhatsApp / Question
- `ContactHelper.kt` — fuzzy contact lookup
- `CallHelper.kt` — places calls directly
- `WhatsAppHelper.kt` — opens WhatsApp with message pre-filled
- `WhatsAppAccessibilityService.kt` — auto-taps Send (only when Pluto itself just opened the chat)
- `ClaudeApiClient.kt` — sends questions to your backend → Claude API (web search enabled)
- `VoiceOutput.kt` — Tamil text-to-speech
- `MainActivity.kt` — permission setup screen
